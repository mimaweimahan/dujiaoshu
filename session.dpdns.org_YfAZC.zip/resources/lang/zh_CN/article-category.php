<?php

return [
    'labels' => [
        'ArticleCategory' => '分类',
        'article-category' => '分类',
    ],
    'fields' => [
        'category_name' => '分类名称',
        'is_open' => '是否启用',
        'ord' => '排序权重 越大越靠前',
    ],
    'options' => [
    ],
];
