<?php 
return [
    'labels' => [
        'Lang' => 'Lang',
        'lang' => 'Lang',
    ],
    'fields' => [
        'icon' => '图标',
        'title' => '语言标题',
        'code' => '语言代码',
    ],
    'options' => [
    ],
];
