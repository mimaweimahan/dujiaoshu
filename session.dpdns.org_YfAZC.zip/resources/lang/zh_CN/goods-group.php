<?php

return [
    'labels' => [
        'GoodsGroup' => '分类',
        'goods-group' => '分类',
    ],
    'fields' => [
        'gp_name' => '分类名称',
        'is_open' => '是否启用',
        'ord' => '排序权重 越大越靠前',
    ],
    'options' => [
    ],
];
