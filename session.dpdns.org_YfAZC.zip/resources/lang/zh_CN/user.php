<?php
return [
    'labels' => [
        'User' => '用户管理',
        'user' => '用户管理',
    ],
    'fields' => [
        'email' => '邮箱',
        'password' => '密码',
        'money' => '余额',
        'grade' => '代理等级',
        'last_ip' => '登录IP',
        'last_login' => '登录时间',
        'register_at' => '注册时间',
        'status' => '状态',
        'invite_code' => '邀请码',
        'pid' => '上级ID',
        'remark' => '备注',
        
    ],
    'options' => [
    ],
];
