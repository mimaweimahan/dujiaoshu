<?php

return [
    'labels' => [
        'GoodsGroup' => '分類',
        'goods-group' => '分類',
    ],
    'fields' => [
        'gp_name' => '分類名稱',
        'is_open' => '是否啟用',
        'ord' => '排序權重 越大越靠前',
    ],
    'options' => [
    ],
];
