### 电报自动开会员
##### 技术文档阅读：https://telegra.ph/%E6%8A%93%E5%8F%96Telegram-Premium-%E8%B5%A0%E9%80%81%E4%BC%9A%E5%91%98API%E6%8E%A5%E5%8F%A3-04-23

### 作者TG：@gd801  电报群：@phpTRON   电报社区：www.telegbot.org


	.env 内请配置你自己的Ton钱包助词器  