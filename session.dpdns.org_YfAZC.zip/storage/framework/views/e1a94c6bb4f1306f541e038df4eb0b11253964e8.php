<script src="/assets/hyper/js/jquery-3.4.1.min.js"></script>
<script src="/assets/hyper/js/vendor.min.js"></script>
<script src="/assets/hyper/js/app.min.js"></script>
<script src="/assets/hyper/js/hyper.js?v=215115"></script>
<script>
    if (getQueryVariable('aff')){
        setCookie('aff', getQueryVariable('aff'), 30);
    }
    function getQueryVariable(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == variable) {
                return pair[1];
            }
        }
        return "";
    }
    function setCookie(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toGMTString();
        document.cookie = cname + "=" + cvalue + "; " + expires;
    }
    function getCookie(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i].trim();
            if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
        }
        return "";
    }
</script>
<?php /**PATH /www/wwwroot/session.dpdns.org/resources/views/hyper/layouts/_script.blade.php ENDPATH**/ ?>