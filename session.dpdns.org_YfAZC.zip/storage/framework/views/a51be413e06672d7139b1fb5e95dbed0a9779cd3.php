<div class="filter-input col-sm-<?php echo e($width, false); ?> " style="<?php echo $style; ?>">
    <div class="form-group"><?php echo $presenter(); ?></div>
</div><?php /**PATH /www/wwwroot/session.dpdns.org/vendor/dcat/laravel-admin/src/../resources/views/filter/where.blade.php ENDPATH**/ ?>