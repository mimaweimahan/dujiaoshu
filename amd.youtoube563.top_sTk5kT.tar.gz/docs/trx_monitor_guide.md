# TRX能量租赁自动化监听程序使用说明

## 📋 功能概述

本程序是一个**TRX能量租赁自动化系统**，用于：
- ✅ 每30秒自动检查指定地址的余额和交易
- ✅ 实时显示 TRX 余额和 USDT 余额
- ✅ 自动检测新的 TRX 到账交易
- ✅ **根据收到的TRX金额自动购买并转出对应能量给付款人**
- ✅ 防止重复处理（已处理的交易会被标记）
- ✅ 美化的控制台输出界面
- ✅ 完整的日志记录

## 🎯 业务逻辑

### 能量租赁流程

1. **用户转账 TRX** → 您的监听地址
2. **程序检测到账** → 自动识别到账金额
3. **匹配能量套餐** → 根据配置查找对应的能量数量
4. **自动购买能量** → 调用 `start_energy_buy()` 函数
5. **转给付款人** → 能量自动转到用户的 TRX 地址

### 套餐配置示例

```json
{
  "1.5": 32000,
  "3": 64000,
  "5": 100000
}
```

**含义**：
- 用户转 **1.5 TRX** → 自动转 **32,000 能量**给用户
- 用户转 **3 TRX** → 自动转 **64,000 能量**给用户
- 用户转 **5 TRX** → 自动转 **100,000 能量**给用户

---

## ⚙️ 配置要求

### 必须配置项

在系统设置中需要配置以下项：

| 配置项 | 说明 | 示例 |
|-------|------|------|
| `tronscan_api` | Tronscan API密钥 | `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` |
| `energy_address` | 要监听的TRX收款地址 | `TXXXXxxxxXXXXxxxxXXXXxxxxXXXXxxxx` |
| `energy_buy_config` | 能量套餐配置（JSON格式） | `{"1.5":32000,"3":64000,"5":100000}` |
| `energy_api_token` | 能量购买API的Token | 参考 `start_energy_buy()` 函数 |
| `energy_api_secret` | 能量购买API的密钥 | 参考 `start_energy_buy()` 函数 |

### 能量套餐配置说明

`energy_buy_config` 的格式为 JSON 对象，格式：`{"TRX金额": 能量数量}`

**示例配置**：
```json
{
  "1.5": 32000,
  "3": 64000,
  "5": 100000,
  "10": 200000
}
```

**含义**：
- 收到 `1.5` TRX → 转出 `32,000` 能量
- 收到 `3` TRX → 转出 `64,000` 能量
- 收到 `5` TRX → 转出 `100,000` 能量
- 收到 `10` TRX → 转出 `200,000` 能量

**注意事项**：
- ⚠️ 金额必须**精确匹配**（误差在0.01以内）
- ⚠️ 如果收到的金额不在配置中，会跳过处理并显示可用套餐
- ⚠️ JSON格式必须正确，否则会报错

### 如何获取 Tronscan API密钥

1. 访问 [Tronscan API](https://tronscan.org/#/api-detail)
2. 注册账号并创建 API Key
3. 将 API Key 配置到系统设置中

---

## 🚀 启动命令

### 基本启动

```bash
php artisan listentrx
```

### 后台持续运行（推荐）

```bash
# 使用 nohup 在后台运行
nohup php artisan listentrx > /dev/null 2>&1 &

# 或使用 screen
screen -S trx_monitor
php artisan listentrx
# 按 Ctrl+A 然后按 D 退出 screen

# 或使用 tmux
tmux new -s trx_monitor
php artisan listentrx
# 按 Ctrl+B 然后按 D 退出 tmux
```

### 使用 Supervisor 管理（生产环境推荐）

创建配置文件 `/etc/supervisor/conf.d/trx_monitor.conf`：

```ini
[program:trx_monitor]
process_name=%(program_name)s
command=php /path/to/your/project/artisan listentrx
autostart=true
autorestart=true
user=www-data
numprocs=1
redirect_stderr=true
stdout_logfile=/path/to/your/project/storage/logs/trx_monitor.log
```

然后启动：

```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start trx_monitor
```

---

## 📊 控制台输出示例

### 启动时

```
╔════════════════════════════════════════════════════════════╗
║         🚀 TRX/USDT 持续监听程序已启动                    ║
╚════════════════════════════════════════════════════════════╝
监听地址: TXXXXxxxxXXXXxxxxXXXXxxxxXXXXxxxx
监听间隔: 30秒
按 Ctrl+C 可停止监听

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 第 1 次监听检查 - 2025-01-01 12:00:00
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 正在获取余额信息...
┌─────────────────────────────────────────┐
│  💎 TRX余额:            123.456789 TRX  │
│  💵 USDT余额:         1,234.567890 USDT │
└─────────────────────────────────────────┘

🔍 正在检查新交易...
📋 已获取到 50 条最近交易
⏰ 上次检查时间: 2025-01-01 11:59:30
✓ 暂无新交易
✅ 本次检查完成

⏳ 等待30秒后进行下一次检查...
```

### 发现新交易时

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 第 5 次监听检查 - 2025-01-01 12:02:00
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 正在获取余额信息...
┌─────────────────────────────────────────┐
│  💎 TRX余额:            223.456789 TRX  │
│  💵 USDT余额:         1,234.567890 USDT │
└─────────────────────────────────────────┘

🔍 正在检查新交易...
📋 已获取到 50 条最近交易
⏰ 上次检查时间: 2025-01-01 12:01:30
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎉 发现 1 笔新交易！
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  💰 TRX到账通知                                   ┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃  金额: 100.000000 TRX                             ┃
┃  哈希: 1234567890abcdef1234567890abcdef... ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

📝 开始处理业务逻辑...

📊 交易详情:
  ├─ 付款地址: TAbcdefgh...rstuvwxyz
  ├─ 收款地址: TXXXXxxxx...XXXXxxxx
  ├─ 交易金额: 100.0 TRX
  ├─ 交易哈希: 1234567890ab...cdef1234567890ab
  └─ 区块时间: 2025-01-01 12:01:45

⚙️ 执行自定义业务逻辑...

  [1/2] 📄 记录交易日志...
        ✓ 日志记录成功
  [2/2] 🔔 发送Webhook通知...
        ✓ Webhook发送成功 (HTTP 200)

✅ 业务逻辑处理完成

✅ 本次检查完成

⏳ 等待30秒后进行下一次检查...
```

---

## 📁 日志文件

### 交易日志文件

自动保存在：`storage/logs/trx_transactions_YYYY-MM-DD.log`

每行一条JSON格式的交易记录：

```json
{
  "timestamp": "2025-01-01 12:01:50",
  "address": "TXXXXxxxxXXXXxxxxXXXXxxxxXXXXxxxx",
  "amount": 100.0,
  "tx_hash": "1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
  "block_timestamp": 1704096105000,
  "from_address": "TAbcdefghijklmnopqrstuvwxyz123456",
  "to_address": "TXXXXxxxxXXXXxxxxXXXXxxxxXXXXxxxx",
  "formatted_time": "2025-01-01 12:01:45"
}
```

### Laravel 日志文件

系统日志保存在：`storage/logs/laravel.log`

包含所有监听过程中的错误、警告和信息日志。

---

## 🔧 工作原理

### 监听流程

```
┌──────────────────────┐
│  程序启动            │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│  加载配置            │
│  - API密钥           │
│  - 监听地址          │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│  进入无限循环        │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│  1. 获取余额         │◄────┐
│     - TRX余额        │     │
│     - USDT余额       │     │
└──────────┬───────────┘     │
           │                 │
           ▼                 │
┌──────────────────────┐     │
│  2. 获取最新交易     │     │
│     - 查询API        │     │
│     - 过滤新交易     │     │
└──────────┬───────────┘     │
           │                 │
           ▼                 │
┌──────────────────────┐     │
│  3. 处理新交易       │     │
│     - 验证交易       │     │
│     - 防重复处理     │     │
│     - 执行业务逻辑   │     │
│     - 记录日志       │     │
│     - 发送通知       │     │
└──────────┬───────────┘     │
           │                 │
           ▼                 │
┌──────────────────────┐     │
│  4. 等待30秒         │     │
└──────────┬───────────┘     │
           │                 │
           └─────────────────┘
```

### 防重复机制

- 使用 Redis/Cache 缓存已处理的交易哈希
- 每个交易哈希缓存30天
- 检测到重复交易会自动跳过

### 时间戳追踪

- 记录最后检查的交易时间戳
- 只处理时间戳大于上次检查时间的交易
- 缓存7天自动过期

---

## 🔔 Webhook 通知格式

如果配置了 `trx_webhook_url`，每次收到新交易时会发送POST请求：

```json
{
  "event": "trx_received",
  "address": "TXXXXxxxxXXXXxxxxXXXXxxxxXXXXxxxx",
  "amount": 100.0,
  "tx_hash": "1234567890abcdef...",
  "timestamp": 1704096105000,
  "from_address": "TAbcdefgh...",
  "to_address": "TXXXXxxxx...",
  "confirmation_time": "2025-01-01 12:01:50",
  "formatted_time": "2025-01-01 12:01:45"
}
```

### Webhook 响应要求

- HTTP状态码 200 表示接收成功
- 其他状态码会被记录为警告

---

## 🎯 自定义业务逻辑

在 `app/Console/Commands/listentrx.php` 文件的 `processBusinessLogic` 方法中添加您的业务代码：

```php
private function processBusinessLogic($address, $amount, $txHash, $fromAddress, $blockTimestamp)
{
    // 示例1: 查找并更新订单
    $order = \App\Models\Order::where('trx_address', $fromAddress)
        ->where('amount', $amount)
        ->where('status', 'pending')
        ->first();
    
    if ($order) {
        $order->status = 'paid';
        $order->tx_hash = $txHash;
        $order->save();
        
        $this->info("  ✓ 订单 #{$order->id} 已标记为已支付");
    }
    
    // 示例2: 发送邮件通知
    // Mail::to('admin@example.com')->send(new TrxReceivedMail($amount, $txHash));
    
    // 示例3: 更新用户余额
    // $user = User::where('trx_address', $fromAddress)->first();
    // if ($user) {
    //     $user->increment('balance', $amount);
    // }
    
    // 更多业务逻辑...
}
```

---

## ❓ 常见问题

### Q1: 如何停止监听程序？

**A:** 
- 如果在前台运行：按 `Ctrl+C`
- 如果使用 screen：`screen -r trx_monitor` 然后按 `Ctrl+C`
- 如果使用 supervisor：`sudo supervisorctl stop trx_monitor`
- 如果使用 nohup：`ps aux | grep listentrx` 找到进程ID，然后 `kill PID`

### Q2: 为什么获取不到余额？

**A:** 检查以下几点：
- Tronscan API密钥是否正确配置
- 监听地址是否正确
- 网络是否能访问 Tronscan API
- 查看日志文件中的错误信息

### Q3: 交易明明到账了，为什么没有检测到？

**A:** 可能的原因：
- 监听程序未运行
- 交易时间早于程序启动时间（查看"上次检查时间"）
- API调用失败（查看日志）
- 交易类型不是 TRX 转账（USDT转账不会被检测）

### Q4: 如何查看程序运行状态？

**A:**
```bash
# 查看进程
ps aux | grep listentrx

# 查看日志（实时）
tail -f storage/logs/laravel.log

# 查看交易日志
tail -f storage/logs/trx_transactions_$(date +%Y-%m-%d).log

# 如果使用 supervisor
sudo supervisorctl status trx_monitor
```

### Q5: 监听间隔可以调整吗？

**A:** 可以！在 `handle()` 方法中修改 `sleep(30)` 的值：
- `sleep(10)` = 10秒检查一次
- `sleep(60)` = 60秒检查一次
- 建议不要低于10秒，避免API请求过于频繁

### Q6: 如何只监听 USDT 转账？

**A:** 目前程序只监听 TRX 转账。如需监听 USDT-TRC20 转账，需要修改：
1. `isTrxTransfer()` 方法，改为检测 TRC20 合约调用
2. `getTransactionAmount()` 方法，改为解析 TRC20 代币金额
3. 这需要更深入的 TRON 区块链知识

### Q7: 程序占用资源多吗？

**A:** 非常低：
- CPU: 几乎为0（大部分时间在sleep）
- 内存: 约20-30MB
- 网络: 每30秒仅2-3个API请求

---

## 🔒 安全建议

1. **API密钥保护**
   - 不要将API密钥硬编码在代码中
   - 使用系统配置存储
   - 定期更换API密钥

2. **Webhook安全**
   - 使用HTTPS协议
   - 验证请求签名
   - 设置IP白名单

3. **日志安全**
   - 定期清理旧日志文件
   - 不要在日志中记录敏感信息
   - 限制日志文件访问权限

4. **程序权限**
   - 使用低权限用户运行程序
   - 不要使用root用户

---

## 📈 监控和维护

### 建议的监控指标

- ✅ 程序运行状态（是否在运行）
- ✅ 最后一次检查时间
- ✅ 余额变化趋势
- ✅ 交易处理数量
- ✅ API请求失败次数

### 维护建议

- 每周检查一次日志文件
- 每月清理一次旧的交易日志
- 定期备份重要的交易记录
- 监控磁盘空间使用

---

## 🆘 故障排查

### 程序无法启动

```bash
# 检查PHP环境
php -v

# 检查扩展
php -m | grep -E "curl|json|redis"

# 测试Redis连接
php artisan tinker
>>> Redis::ping()

# 检查配置
php artisan config:cache
php artisan cache:clear
```

### API请求失败

```bash
# 测试API连接
curl -H "TRON-PRO-API-KEY: your-api-key" \
     "https://apilist.tronscanapi.com/api/account?address=TXXXXxxxx..."
```

### 查看详细错误

```bash
# 开启调试模式
# 修改 .env 文件
APP_DEBUG=true

# 重启程序
```

---

## 📞 技术支持

如有问题，请：
1. 查看本文档
2. 检查日志文件
3. 查看 Laravel 日志
4. 联系开发团队

---

**开发团队** | **最后更新：2025-01-01** | **版本：v2.0**

