<?php

return [
    'labels' => [
        'Emailtpl' => '郵件模板',
        'emailtpl' => '郵件模板',
    ],
    'fields' => [
        'tpl_name' => '郵件標題',
        'tpl_content' => '郵件內容',
        'tpl_token' => '郵件標識',
    ],
    'options' => [
    ],
];
