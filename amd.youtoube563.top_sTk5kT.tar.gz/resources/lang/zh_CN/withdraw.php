<?php
return [
    'labels' => [
        'Withdraw' => '提现',
        'withdraw' => '提现',
    ],
    'fields' => [
        'user_id' => '用户ID',
        'amount' => '金额',
        'type' => '类型',
        'address' => '地址',
        'status' => '状态',
    ],
    'options' => [
    ],
];
