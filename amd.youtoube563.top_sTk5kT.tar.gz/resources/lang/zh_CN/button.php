<?php 
return [
    'labels' => [
        'Button' => 'Button',
        'button' => 'Button',
    ],
    'fields' => [
        'title' => '标题',
        'keyword' => '关键词',
        'lang' => '所属语言',
        'content' => '内容',
        'mode' => '模式',
        'is_show' => '是否展示url',
        'button_json' => '按钮内容',
    ],
    'options' => [
    ],
];
